#ifndef MARIO_H
#define MARIO_H

/* Jocul Mario simplu: Start/Update/Render */
void Start(void);
void Update(void);
void Render(void);

#endif /* MARIO_H */
